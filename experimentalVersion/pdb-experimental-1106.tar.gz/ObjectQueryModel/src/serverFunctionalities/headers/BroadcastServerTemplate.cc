#ifndef OBJECTQUERYMODEL_BROADCASTSERVERTEMPLATE_CC
#define OBJECTQUERYMODEL_BROADCASTSERVERTEMPLATE_CC

#include "BroadcastServer.h"
#include "ResourceManagerServer.h"
#include "PDBWorker.h"
#include "PDBWork.h"
#include "GenericWork.h"
#include "UseTemporaryAllocationBlock.h"

namespace pdb {

template <class MsgType, class PayloadType, class ResponseType>
void BroadcastServer::broadcast(Handle<MsgType> broadcastMsg, Handle<Vector<Handle<PayloadType>>> broadcastData,
        std::vector<std::pair<std::string, int>> receivers,
        std::function<void(Handle<ResponseType>, std::string)> callBack,
        std::function<void(std::string, std::string)> errorCallBack) {

    if (receivers.size() == 0) {
        const auto nodes = getFunctionality<ResourceManagerServer>().getAllNodes();
        for (int i = 0; i < nodes->size(); i++) {
            std::string address = static_cast<std::string>((*nodes)[i]->getAddress());
            int port = (*nodes)[i]->getPort();
            receivers.push_back(std::pair<std::string, int>(address, port));
        }
    }

    int errors = 0;
    int success = 0;
    auto failures = make_shared<std::vector<std::pair<std::string, std::string>>>();

    PDBBuzzerPtr buzzer = make_shared<PDBBuzzer> (
            [&] (PDBAlarm myAlarm, std::string serverName) {
                lock.lock();
                // Handle the error cases here
                if (myAlarm == PDBAlarm::GenericError) {
                    errors ++;
                    std::cout << "Error broadcast " << errors << " to " << serverName << std::endl;
                    lock.unlock();
                } else {
                    success++;
                    std::cout << "Successful broadcast " << success << " to " << serverName << std::endl;
                    lock.unlock();
                }

    });

    for (int i = 0; i < receivers.size(); i++) {
        PDBWorkerPtr myWorker = getWorker();

        std::string serverName = receivers[i].first + ":" + std::to_string(receivers[i].second);

        PDBWorkPtr myWork = make_shared <GenericWork> (
            [&, i, serverName] (PDBBuzzerPtr callerBuzzer) {

            std::string errMsg;

            PDBCommunicatorPtr communicator = std :: make_shared<PDBCommunicator>();

            if(communicator->connectToInternetServer(this->logger, receivers[i].second, receivers[i].first, errMsg)) {
                errorCallBack(errMsg, serverName);
                callerBuzzer->buzz (PDBAlarm :: GenericError, serverName);
                return;
            }
            Handle<MsgType> broadcastMsgCopy = deepCopy<MsgType>(broadcastMsg);
            if (!communicator->sendObject<MsgType>(broadcastMsgCopy, errMsg)) {
                errorCallBack(errMsg, serverName);
                callerBuzzer->buzz (PDBAlarm :: GenericError, serverName);
                return;
            }
            if (broadcastData != nullptr) {
                Handle<Vector<Handle<PayloadType>>> payloadCopy = deepCopy<Vector<Handle<PayloadType>>> (broadcastData);
                if (!communicator->sendObject(payloadCopy, errMsg)) {
                    errorCallBack(errMsg, serverName);
                    callerBuzzer->buzz (PDBAlarm :: GenericError, serverName);
                    return;
                }
            }
            const UseTemporaryAllocationBlock myBlock{communicator->getSizeOfNextObject()};
            bool err;
            Handle<ResponseType> result = communicator->getNextObject<ResponseType>(err, errMsg);
            callBack(result, serverName);
            callerBuzzer->buzz(PDBAlarm :: WorkAllDone, serverName);
        });
        myWorker->execute(myWork, buzzer);
    }
    while(errors + success < receivers.size()) {
        buzzer->wait();
    }
}

template<class DataType>
Handle<DataType> BroadcastServer::deepCopy(const Handle<DataType> & original) {
    Handle<DataType> newObject = makeObject<DataType>();
    (* newObject) = (* original);
    return newObject;
}

}


#endif
