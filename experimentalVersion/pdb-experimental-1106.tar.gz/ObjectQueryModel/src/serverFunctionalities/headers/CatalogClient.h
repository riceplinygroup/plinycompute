
#ifndef CATALOG_CLIENT_H
#define CATALOG_CLIENT_H

namespace pdb {

class CatalogClient;

}

#include "ServerFunctionality.h"
#include "PDBLogger.h"
#include "PDBServer.h"
#include "CatalogDatabaseMetadata.h"
#include "CatalogNodeMetadata.h"
#include "CatalogSetMetadata.h"

#include "CatalogPrintMetadata.h"

namespace pdb {

class CatalogClient : public ServerFunctionality {

public:

	// destructor
	~CatalogClient ();

	// these give us the port and the address of the catalog
	CatalogClient (int port, std :: string address, PDBLoggerPtr myLogger);

	// function to register event handlers associated with this server functionality
	virtual void registerHandlers (PDBServer &forMe) override;

	// this uses the name of the object to find the corresponding identifier
	int16_t searchForObjectTypeName (std :: string objectTypeName);

	// this downloads the shared library assoicated with the identifier, putting it at the specified location
	bool getSharedLibrary (int16_t identifier, std :: string objectFile);	

	// this registers a type with the catalog
	// returns true on success, false on fail
	bool registerType (std :: string fileContainingSharedLib, std :: string &errMsg);

        // shuts down the server that we are connected to... returns true on success
        bool shutDownServer (std :: string &errMsg);

	// this returns the type of object in the specified set, as a type name; returns "" on err
	std :: string getObjectType (std :: string databaseName, std :: string setName, std :: string &errMsg);

	// this creates a new database... returns true on success
	// returns true on success, false on fail
	bool createDatabase (std :: string databaseName, std :: string &errMsg);

	// registers metadata about a database
	bool registerDatabaseMetadata (std :: string databaseName, std :: string &errMsg);

    // registers metadata about a node in the cluster
    bool registerNodeMetadata (pdb :: Handle<pdb :: CatalogNodeMetadata> nodeData, std :: string &errMsg);

    // a template for registering a piece of metadata in the catalog
    template <class Type>
    bool registerGenericMetadata (pdb :: Handle<Type> metadataItem, std :: string &errMsg);

	// this creates a new set in a given database... returns true on success
	// returns true on success, false on fail
	template <class DataType>
	bool createSet (std :: string databaseName, std :: string setName, std :: string &errMsg);

	// same as above, but here we use the type code
	bool createSet (int16_t identifier, std :: string databaseName, std :: string setName, std :: string &errMsg);

	// prints the content of the metadata in the catalog
    bool printCatalogMetadata (std :: string itemToSearch, std :: string &errMsg);

    PDBLoggerPtr getLogger();

private:

	int port;
	std :: string address;
	PDBLoggerPtr myLogger;

	// serialize access to shared library loading
	pthread_mutex_t workingMutex;
};

}

#include "CatalogClientTemplates.cc"

#endif
