#ifndef OBJECTQUERYMODEL_BROADCASTSERVER_CC
#define OBJECTQUERYMODEL_BROADCASTSERVER_CC

#include "BroadcastServer.h"
namespace pdb {

BroadcastServer::BroadcastServer(PDBLoggerPtr logger) {
    this->logger = logger;
}

BroadcastServer::~BroadcastServer() {
    // no-op
}

void BroadcastServer::registerHandlers(PDBServer &forMe) {
    // no-op
}

}

#endif

