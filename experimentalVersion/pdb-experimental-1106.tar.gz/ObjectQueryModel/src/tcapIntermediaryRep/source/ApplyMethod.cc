#include "ApplyMethod.h"

namespace pdb_detail
{
    ApplyMethodPtr makeApplyMethod(string executorId, string functionId, string outputTableId, string outputColumnId,
                                   TableColumns inputColumns, shared_ptr<vector<Column>> columnsToCopyToOutputTable)
    {
        return make_shared<ApplyMethod>(executorId, functionId, outputTableId, outputColumnId, inputColumns,
                                        columnsToCopyToOutputTable);
    }
}