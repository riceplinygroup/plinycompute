#include "Filter.h"

using std::make_shared;

namespace pdb_detail
{

    FilterPtr makeFilter(string inputTableId, string filterColumnId, string outputTableId,
                         shared_ptr<vector<Column>> columnsToCopyToOutputTable)
    {
        return make_shared<Filter>(inputTableId, filterColumnId, outputTableId, columnsToCopyToOutputTable);
    }
}