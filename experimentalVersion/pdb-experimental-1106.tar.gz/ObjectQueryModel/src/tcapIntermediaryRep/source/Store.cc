#include "Store.h"

namespace pdb_detail
{
    StorePtr makeStore(string tableId, string destination)
    {
        return make_shared<Store>(tableId, destination);
    }
}