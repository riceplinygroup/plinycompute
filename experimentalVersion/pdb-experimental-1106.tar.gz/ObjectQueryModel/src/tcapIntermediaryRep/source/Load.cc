#include "Load.h"

namespace pdb_detail
{
    LoadPtr makeLoad(string outputTableId, string outputColumnId, string source)
    {
        return make_shared<Load>(outputTableId, outputColumnId, source);
    }
}