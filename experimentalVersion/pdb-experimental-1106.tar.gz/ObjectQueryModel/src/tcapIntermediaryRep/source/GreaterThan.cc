#include "GreaterThan.h"

using std::make_shared;

namespace pdb_detail
{
    GreaterThanPtr makeGreaterThan(Column leftHandSide, Column rightHandSide, Column outputColumn,
                                   shared_ptr<vector<Column>> columnsToCopyToOutputTable, string executorId)
    {
        return make_shared<GreaterThan>(leftHandSide, rightHandSide, outputColumn, columnsToCopyToOutputTable, executorId);
    }
}