#include "ApplyFunction.h"

namespace pdb_detail
{

    ApplyFunctionPtr makeApplyFunction(string executorId, string functionId, string outputTableId, string outputColumnId,
                      TableColumns inputColumns, shared_ptr<vector<Column>> columnsToCopyToOutputTable)
    {
        return make_shared<ApplyFunction>(executorId, functionId, outputTableId, outputColumnId, inputColumns,
                                          columnsToCopyToOutputTable);
    }
}