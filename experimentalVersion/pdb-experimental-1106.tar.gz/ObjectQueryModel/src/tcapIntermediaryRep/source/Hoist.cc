#include "Hoist.h"

using std::make_shared;

namespace pdb_detail
{

    HoistPtr makeHoist(string fieldId, Column inputColumn, Column outputColumn,
                       shared_ptr<vector<Column>> columnsToCopyToOutputTable, string executorId)
    {
        return make_shared<Hoist>(fieldId, inputColumn, outputColumn, columnsToCopyToOutputTable, executorId);
    }
}