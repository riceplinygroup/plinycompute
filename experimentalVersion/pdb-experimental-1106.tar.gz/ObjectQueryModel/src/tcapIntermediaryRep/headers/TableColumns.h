#ifndef PDB_TCAPINTERMEDIARYREP_TABLECOLUMNS_H
#define PDB_TCAPINTERMEDIARYREP_TABLECOLUMNS_H

#include <memory>
#include <string>
#include <vector>

using std::make_shared;
using std::shared_ptr;
using std::string;
using std::vector;

namespace pdb_detail
{
    /**
     * columnNames may not be empty.
     */
    class TableColumns
    {
    public:

        const string tableName;

        const shared_ptr<vector<string>> columnIds;

        TableColumns(string tableName, shared_ptr<vector<string>> columnIds)
            : tableName(tableName), columnIds(columnIds)
        {
        }

        TableColumns(string tableName, string columnId)
                : tableName(tableName), columnIds(make_shared<vector<string>>())
        {
            columnIds->push_back(columnId);
        }

        TableColumns(string tableName, string columnId1, string columnId2)
                : tableName(tableName), columnIds(make_shared<vector<string>>())
        {
            columnIds->push_back(columnId1);
            columnIds->push_back(columnId2);
        }

        string operator[](vector<string>::size_type index) const
        {
            return columnIds->operator[](index);
        }

    };
}

#endif //PDB_TCAPINTERMEDIARYREP_TABLECOLUMNS_H
