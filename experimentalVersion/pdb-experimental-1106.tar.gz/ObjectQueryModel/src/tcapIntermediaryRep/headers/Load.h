#ifndef PDB_TCAPINTERMEDIARYREP_LOAD_H
#define PDB_TCAPINTERMEDIARYREP_LOAD_H

#include "ApplyFunction.h"
#include "Instruction.h"

namespace pdb_detail
{
    class Load : public Instruction
    {
    public:
        
        const string outputColumnId;

        const string outputTableId;

        const string source;

        Load(string outputTableId, string outputColumnId, string source)
                :Instruction(InstructionType::load), outputColumnId(outputColumnId), outputTableId(outputTableId),
                 source(source)
        {
        }

        void match(function<void(Load&)> forLoad, function<void(ApplyFunction&)>, function<void(ApplyMethod&)>,
                   function<void(Filter&)>, function<void(Hoist&)>, function<void(GreaterThan&)>,
                   function<void(Store&)> forStore) override
        {
            forLoad(*this);
        }

    };

    typedef shared_ptr<Load> LoadPtr;

    LoadPtr makeLoad(string outputTableId, string outputColumnId, string source);

}

#endif //PDB_TCAPINTERMEDIARYREP_LOAD_H
