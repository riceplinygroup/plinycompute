#ifndef PDB_TCAPINTERMEDIARYREP_GREATERTHAN_H
#define PDB_TCAPINTERMEDIARYREP_GREATERTHAN_H

#include <memory>
#include <vector>

#include "Column.h"
#include "Instruction.h"

using std::shared_ptr;
using std::vector;

namespace pdb_detail
{
    class GreaterThan : public Instruction
    {
    public:

        const Column leftHandSide;

        const Column rightHandSide;

        const Column outputColumn;

        /**
         * Any option columns to copy into the output table during its contruction.
         */
        const shared_ptr<vector<Column>> columnsToCopyToOutputTable;

        const string executorId;

        GreaterThan(Column leftHandSide, Column rightHandSide, Column outputColumn,
                    shared_ptr<vector<Column>> columnsToCopyToOutputTable, string executorId)

                    : Instruction(InstructionType::greater_than), leftHandSide(leftHandSide),
                      rightHandSide(rightHandSide), outputColumn(outputColumn),
                      columnsToCopyToOutputTable(columnsToCopyToOutputTable), executorId(executorId)
        {
        }

        void match(function<void(Load&)> forLoad, function<void(ApplyFunction&)>, function<void(ApplyMethod&)>,
                   function<void(Filter&)>, function<void(Hoist&)>, function<void(GreaterThan&)> forGreaterThan,
                   function<void(Store&)>)
        {
            forGreaterThan(*this);
        }

    };

    typedef shared_ptr<GreaterThan> GreaterThanPtr;

    GreaterThanPtr makeGreaterThan(Column leftHandSide, Column rightHandSide, Column outputColumn,
                                   shared_ptr<vector<Column>> columnsToCopyToOutputTable, string executorId);
}

#endif //PDB_TCAPINTERMEDIARYREP_GREATERTHAN_H
