#ifndef PDB_TCAPINTERMEDIARYREP_FILTER_H
#define PDB_TCAPINTERMEDIARYREP_FILTER_H

#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "ApplyFunction.h"
#include "ApplyMethod.h"
#include "Filter.h"
#include "Hoist.h"
#include "Column.h"
#include "Load.h"

using std::function;
using std::shared_ptr;
using std::string;
using std::vector;

using pdb_detail::Column;

namespace pdb_detail
{
    class Filter : public Instruction
    {

    public:

        /**
         * The id of the table to be created by application of the instruction.
         */
        const string inputTableId;

        /**
         * The namme of the column in the input table on which the filter operation operates.
         */
        const string filterColumnId;

        /**
         * The id of the table to be created by application of the instruction.
         */
        const string outputTableId;

        /**
         * Any option columns to copy into the output table during its contruction.
         */
        const shared_ptr<vector<Column>> columnsToCopyToOutputTable;

        Filter(string inputTableId, string filterColumnId, string outputTableId,
               shared_ptr<vector<Column>> columnsToCopyToOutputTable)
            :
                Instruction(InstructionType::filter),
                inputTableId(inputTableId), filterColumnId(filterColumnId), outputTableId(outputTableId),
                columnsToCopyToOutputTable(columnsToCopyToOutputTable)
        {

        }

        void match(function<void(Load&)>, function<void(ApplyFunction&)>, function<void(ApplyMethod&)>,
                   function<void(Filter&)> forFilter, function<void(Hoist&)>, function<void(GreaterThan&)>,
                   function<void(Store&)>)
        {
            forFilter(*this);
        }
    };

    typedef shared_ptr<Filter> FilterPtr;

    FilterPtr makeFilter(string inputTableId, string filterColumnId, string outputTableId,
                         shared_ptr<vector<Column>> columnsToCopyToOutputTable);
}

#endif //PDB_TCAPINTERMEDIARYREP_COLUMN_H
