#ifndef PDB_TCAPINTERMEDIARYREP_STORE_H
#define PDB_TCAPINTERMEDIARYREP_STORE_H

#include "ApplyFunction.h"
#include "Instruction.h"

namespace pdb_detail
{
    class Store : public Instruction
    {
    public:

        const string tableId;

        const string destination;

        Store(string tableId, string destination)
                :Instruction(InstructionType::store), tableId(tableId), destination(destination)
        {
        }

        void match(function<void(Load&)>, function<void(ApplyFunction&)>, function<void(ApplyMethod&)>,
                   function<void(Filter&)>, function<void(Hoist&)>, function<void(GreaterThan&)>,
                   function<void(Store&)> forStore)
        {
            forStore(*this);
        }
    };

    typedef shared_ptr<Store> StorePtr;

    StorePtr makeStore(string tableId, string destination);
}

#endif //PDB_TCAPINTERMEDIARYREP_STORE_H
