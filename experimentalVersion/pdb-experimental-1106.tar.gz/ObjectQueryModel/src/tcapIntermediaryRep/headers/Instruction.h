#ifndef PDB_TCAPINTERMEDIARYREP_INSTRUCTION_H
#define PDB_TCAPINTERMEDIARYREP_INSTRUCTION_H

#include <memory>
#include <functional>

using std::function;
using std::shared_ptr;

namespace pdb_detail
{
    enum InstructionType
    {
        filter, load, apply_function, apply_method, hoist, greater_than, store
    };

    class Load;

    class ApplyFunction;

    class ApplyMethod;

    class Filter;

    class Hoist;

    class GreaterThan;

    class Store;

    class Instruction
    {
    public:

        const InstructionType instructionType;

        Instruction(InstructionType type) : instructionType(type)
        {
        }

        virtual void match(function<void(Load&)> forLoad, function<void(ApplyFunction&)> forApplyFunc,
                           function<void(ApplyMethod&)> forApplyMethod, function<void(Filter&)> forFilter,
                           function<void(Hoist&)> forHoist, function<void(GreaterThan&)> forGreaterThan,
                           function<void(Store&)> forStore) = 0;



    };

    typedef shared_ptr<Instruction> InstructionPtr;
}

#endif //PDB_TCAPINTERMEDIARYREP_INSTRUCTION_H
