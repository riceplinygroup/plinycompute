
#ifndef PDB_LOGICALPLANTESTS_LOGICALPLANTESTSRUNNER_H
#define PDB_LOGICALPLANTESTS_LOGICALPLANTESTSRUNNER_H

#include "qunit.h"

using QUnit::UnitTest;

namespace pdb_tests
{
    void runLogicalPlanTests(UnitTest &qunit);
}


#endif //PDB_LOGICALPLANTESTS_LOGICALPLANTESTSRUNNER_H
