
#ifndef SHARED_EMPLOYEE_C
#define SHARED_EMPLOYEE_C

#include "GetVTable.h"
#include "SharedEmployee.h"

GET_V_TABLE (SharedEmployee)

#endif
