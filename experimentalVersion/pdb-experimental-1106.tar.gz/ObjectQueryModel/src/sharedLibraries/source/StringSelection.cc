
#ifndef STRING_SELECTION_CC
#define STRING_SELECTION_CC

#include "GetVTable.h"
#include "StringSelection.h"


GET_V_TABLE (StringSelection)

#endif
