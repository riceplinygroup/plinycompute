#include "TcapTestsRunner.h"

#include "LexTcapTests.h"

namespace pdb_tests
{
    void runTcapTests(UnitTest &qunit)
    {
        testLexTcap1(qunit);
    }
}
