#ifndef PDB_RCAPLEXERTESTS_TCAPTESTSRUNNER_H
#define PDB_RCAPLEXERTESTS_TCAPTESTSRUNNER_H

#include "qunit.h"

using QUnit::UnitTest;

namespace pdb_tests
{
    void runTcapTests(UnitTest &qunit);
}

#endif //PDB_RCAPLEXERTESTS_TCAPTESTSRUNNER_H
