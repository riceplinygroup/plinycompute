#ifndef PDB_TCAPLEXERTESTS_LEXTCAPTESTS_H
#define PDB_TCAPLEXERTESTS_LEXTCAPTESTS_H

#include "qunit.h"

using QUnit::UnitTest;

namespace pdb_tests
{
    void testLexTcap1(UnitTest &qunit);
}

#endif //PDB_TCAPLEXERTESTS_LEXTCAPTESTS_H
