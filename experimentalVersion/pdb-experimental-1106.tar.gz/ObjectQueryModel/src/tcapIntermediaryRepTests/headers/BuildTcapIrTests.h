//
// Created by barnett on 10/25/16.
//

#ifndef PDB_TCAPINTERMEDIARYREPTESTS_BUILDTCAPIRTESTS_H
#define PDB_TCAPINTERMEDIARYREPTESTS_BUILDTCAPIRTESTS_H

#include "qunit.h"

using QUnit::UnitTest;

namespace pdb_tests
{
    void buildTcapIrTest1(UnitTest &qunit);

    void buildTcapIrTest2(UnitTest &qunit);

    void buildTcapIrTest3(UnitTest &qunit);

    void buildTcapIrTest4(UnitTest &qunit);

    void buildTcapIrTest5(UnitTest &qunit);

    void buildTcapIrTest6(UnitTest &qunit);

    void buildTcapIrTest7(UnitTest &qunit);
}

#endif //PDB_TCAPINTERMEDIARYREPTESTS_BUILDTCAPIRTESTS_H
