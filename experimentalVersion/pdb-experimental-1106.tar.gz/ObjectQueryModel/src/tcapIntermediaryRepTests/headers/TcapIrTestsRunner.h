//
// Created by barnett on 10/25/16.
//

#ifndef PDB_TCAPINTERMEDIARYREPTESTS_TCAPIRTESTSRUNNER_H
#define PDB_TCAPINTERMEDIARYREPTESTS_TCAPIRTESTSRUNNER_H

#include "qunit.h"

using QUnit::UnitTest;

namespace pdb_tests
{
    void runBuildTcapIrTests(UnitTest &qunit);
}


#endif //PDB_TCAPIRTESTSRUNNER_H
