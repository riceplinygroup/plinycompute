#ifndef OBJECTQUERYMODEL_NODEPARTITIONDATA_CC
#define OBJECTQUERYMODEL_NODEPARTITIONDATA_CC

#include "NodePartitionData.h"

namespace pdb {

    NodePartitionData::NodePartitionData(Handle<NodeDispatcherData> nodeData, std::pair<std::string, std::string> setAndDatabaseName) {
        NodePartitionData(nodeData->getNodeId(), nodeData->getPort(), nodeData->getAddress(), setAndDatabaseName);
    }

    NodePartitionData::NodePartitionData(NodeID nodeId, int port, std::string address, std::pair<std::string, std::string> setAndDatabaseName)
            : nodeId(nodeId), port(port), address(address), setName(setAndDatabaseName.first), databaseName(setAndDatabaseName.second) {
        this->totalBytesSent = 0;
    }

    NodeID NodePartitionData::getNodeId() const {
        return this->nodeId;
    }
    int NodePartitionData::getPort() const {
        return this->port;
    }
    std::string NodePartitionData::getAddress() const {
        return this->address;
    }
    std::string NodePartitionData::getSetName() const {
        return this->setName;
    }
    std::string NodePartitionData::getDatabaseName() const {
        return this->databaseName;
    }
    size_t NodePartitionData::getTotalBytesSent() const {
        return this->totalBytesSent;
    }
}

#endif