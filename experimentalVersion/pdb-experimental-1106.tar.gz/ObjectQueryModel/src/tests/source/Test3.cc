
#include <cstddef>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <cstring>
#include <ctime>
#include <chrono>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string>

#include "InterfaceFunctions.h"
#include "Employee.h"
#include "Supervisor.h"

using namespace pdb;

int main () {

	// for timing
	auto begin = std::chrono::high_resolution_clock::now();

	// load up the allocator with RAM
	makeObjectAllocatorBlock (1024 * 1024 * 24, false);

	// get the file size
	std::ifstream in ("testfile", std::ifstream::ate | std::ifstream::binary);
	size_t fileLen = in.tellg(); 

	// read in the serialized record
	int filedesc = open ("testfile", O_RDONLY);
	Record <Vector <Handle <Supervisor>>> *myNewBytes = (Record <Vector <Handle <Supervisor>>> *) malloc (fileLen);
	read (filedesc, myNewBytes, fileLen);

	// get the root object
	Handle <Vector <Handle <Supervisor>>> mySupers = myNewBytes->getRootObject ();

	// and loop through it, copying over some employees
	int numSupers = (*mySupers).size ();
	Handle <Vector <Handle <Employee>>> result = makeObject <Vector <Handle <Employee>>> (10);
	for (int i = 0; i < numSupers; i++) {
		result->push_back ((*mySupers)[i]->getEmp (i % 10));
	}	

	// now, we serialize those employees
	close (filedesc);

	Record <Vector <Handle <Employee>>> *myBytes = getRecord <Vector <Handle <Employee>>> (result);
	filedesc = open ("testfile2", O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
	write (filedesc, myBytes, myBytes->numBytes ());
	close (filedesc);
	std :: cout << "Wrote " << myBytes->numBytes () << " bytes to the file.\n";

	auto end = std::chrono::high_resolution_clock::now();
	std::cout << "Duration to do the copies and then write the new objects: " <<
		std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count() << " ns." << std::endl;
	std :: cout << "Are " << getBytesAvailableInCurrentAllocatorBlock () << " bytes left in the current allocation block.\n";

	for (int i = 0; i < numSupers; i += 1000) {
		(*result)[i]->print ();
		std :: cout << "\n";
	}

	free (myNewBytes);
}
	
