#include <iostream>
#include "TokenStream.h"

namespace pdb_detail
{

    TokenStream::TokenStream(shared_ptr<vector<Lexeme>>tokens) :_tokens(tokens)
    {
    }

    bool TokenStream::hasNext()
    {
        return _readIndex < _tokens->size();
    }

    Lexeme TokenStream::advance()
    {
        if(_readIndex>=_tokens->size())
            return Lexeme("", Lexeme::UNKNOWN_TYPE);

        return _tokens->operator[](_readIndex++);
    }

    Lexeme TokenStream::peek()
    {
        return _tokens->operator[](_readIndex);
    }

// useful for debugging.
//
//        void TokenStream::printTypes()
//        {
//            for(int i = _readIndex; i<_tokens->size(); i++)
//            {
//                std::cerr << _tokens->operator[](i).tokenType << "\n";
//            }
//        }

}