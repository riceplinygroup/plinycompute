#include "Lexeme.h"

namespace pdb_detail
{
    Lexeme::Lexeme(string token, int tokenType) : _token(token), tokenType(tokenType)
    {
    }

    string Lexeme::getToken()
    {
        return _token;
    }

}

