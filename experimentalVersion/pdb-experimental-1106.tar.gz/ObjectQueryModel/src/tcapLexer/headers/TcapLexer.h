#ifndef PDB_TCAPLEXER_TCAPLEXER_H
#define PDB_TCAPLEXER_TCAPLEXER_H

#include "TokenStream.h"

namespace pdb_detail
{
    /**
     * Tokenize source into a token stream.
     *
     * Unrecognized tokens will be reported as Lexeme::UNKNOWN_TYPE
     *
     * @param source the input string
     * @return the tokenization of source
     */
    TokenStream lexTcap(const string &source);
}

#endif //PDB_TCAPLEXER_TCAPLEXER_H
