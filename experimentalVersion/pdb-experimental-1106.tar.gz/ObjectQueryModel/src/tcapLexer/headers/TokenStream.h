
#ifndef PDB_TCAPLEXER_TOKENSTREAM_H
#define PDB_TCAPLEXER_TOKENSTREAM_H

#include <memory>
#include <vector>

#include "Lexeme.h"

using std::shared_ptr;
using std::vector;

using pdb_detail::Lexeme;

namespace pdb_detail
{
    /**
     * A sequence of tokens.
     */
    class TokenStream
    {
    public:

        /**
         * Constructs a stream from the given tokens.
         *
         * @param tokens the tokens of the stream
         * @return a new token stream
         */
        TokenStream(shared_ptr<vector<Lexeme>> tokens);

        /**
         * @return true if any tokens remain, else false.
         */
        bool hasNext();

        /**
         * @return
         */
        Lexeme advance();

        Lexeme peek();

 //useful for debugging.
 //       void printTypes();

    private:

        int _readIndex = 0;

        shared_ptr<vector<Lexeme>> _tokens;

    };
}

#endif //PDB_TCAPLEXER_TOKENSTREAM_H
