
#ifndef TEST_47_H
#define TEST_47_H

#include "Join.h"
#include "PDBString.h"
#include "Query.h"
#include "Lambda.h"
#include "Selection.h"
#include "QueryClient.h"
#include "QueryOutput.h"
#include "StorageClient.h"
#include "ChrisSelection.h"
#include "StringSelection.h"
#include "SharedEmployee.h"
#include "QueryNodeIr.h"
#include "Selection.h"
#include "SelectionIr.h"
#include "Set.h"
#include "SourceSetNameIr.h"
#include "Supervisor.h"
#include "ProjectionIr.h"
#include "QueryGraphIr.h"
#include "QueryOutput.h"
#include "IrBuilder.h"
#include "QuerySchedulerServer.h"
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <chrono>
#include <fcntl.h>

using namespace pdb;
int main (int argc, char * argv[]) {

	// for allocations
	const UseTemporaryAllocationBlock tempBlock {1024 * 1024 * 24};

        Handle<Array<char>> data = makeObject<Array<char>> (9);
        std :: cout << "typeCode=" << data.getTypeCode() << std :: endl;


	string errMsg;
	PDBLoggerPtr myLogger = make_shared <pdb :: PDBLogger> ("clientLog");

	Handle <ChrisSelection> myFirstSelect = makeObject <ChrisSelection> ();
	Handle <StringSelection> mySecondSelect = makeObject <StringSelection> ();
	Handle <QueryOutput <String>> outputOne = makeObject <QueryOutput <String>> ("chris_db", "output_set1", myFirstSelect);
	Handle <QueryOutput <String>> outputTwo = makeObject <QueryOutput <String>> ("chris_db", "output_set2", mySecondSelect);

        Handle<Vector <Handle<QueryBase>>> queries = makeObject<Vector<Handle<QueryBase>>>();
        queries->push_back(outputOne);
        queries->push_back(outputTwo);

        Handle<QueryBase> query = outputTwo;
        
        std :: cout << query->getNumInputs() << std :: endl;
        const UseTemporaryAllocationBlock tempBlock1 {1024 * 1024 * 24};

        Handle<QueryBase> newQuery = makeObject<QueryOutput <Object>>();
        (* newQuery) = (* query);
        std :: cout << newQuery->getNumInputs() << std :: endl;

        Handle<Array<char>> newData = makeObject<Array<char>>();        
        (* newData) = (*data);
        std :: cout << "typeCode=" << newData.getTypeCode() << std :: endl;
         
}

#endif
