
#ifndef TEST_603_CC
#define TEST_603_CC

#include "PDBServer.h"
#include "CatalogServer.h"
#include "CatalogClient.h"
#include "StorageClient.h"
#include "PangeaStorageServer.h"
#include "FrontendQueryTestServer.h"
#include "HermesExecutionServer.h"

int main (int argc, char * argv[] ) {

       std :: cout << "Starting up a PDB server!!\n";
       std :: cout << "First run this, then run bin/test46 in another window, then run this again, then run bin/test44 in another window" << std :: endl;
       std :: cout << "You can add one parameter as the thread num" << std :: endl;
       int numThreads = 1;
       if (argc > 1) {
           numThreads = atoi(argv[1]);
       }
       std :: cout << "Thread number =" << numThreads << std :: endl;
  
       pdb :: PDBLoggerPtr logger = make_shared <pdb :: PDBLogger> ("frontendLogFile.log");
       ConfigurationPtr conf = make_shared < Configuration > ();
       conf->setNumThreads(numThreads);
       SharedMemPtr shm = make_shared< SharedMem > (conf->getShmSize(), logger);
       conf->printOut();

       if(shm != nullptr) {
               pid_t child_pid = fork();
               if(child_pid == 0) {
                   //I'm the backend server
                   pdb :: PDBLoggerPtr logger = make_shared <pdb :: PDBLogger> ("backendLogFile.log");
                   pdb :: PDBServer backEnd (conf->getBackEndIpcFile(), 100, logger);
                   backEnd.addFunctionality<pdb :: HermesExecutionServer>(shm, backEnd.getWorkerQueue(), logger, conf);
                   bool usePangea = true;
                   backEnd.addFunctionality<pdb :: StorageClient> (8108, "localhost", make_shared <pdb :: PDBLogger> ("clientLog"), usePangea);
                   backEnd.startServer(nullptr);

               } else if (child_pid == -1) {
                   std :: cout << "Fatal Error: fork failed." << std :: endl;
               } else {
                   //I'm the frontend server
                   pdb :: PDBServer frontEnd (8108, 100, logger);
                   frontEnd.addFunctionality<pdb :: PangeaStorageServer> (shm, frontEnd.getWorkerQueue(), logger, conf);
                   frontEnd.getFunctionality<pdb :: PangeaStorageServer>().startFlushConsumerThreads();
                   frontEnd.addFunctionality<pdb :: FrontendQueryTestServer>();
                   frontEnd.addFunctionality <pdb :: CatalogServer> ("CatalogDir", true, false);
                   frontEnd.addFunctionality <pdb :: CatalogClient> (8108, "localhost", logger);
                   frontEnd.startServer (nullptr);
               }
               
       }
}

#endif

