
#ifndef CHRIS_SELECT_CC
#define CHRIS_SELECT_CC

#include "ChrisSelection.h"
#include "GetVTable.h"

GET_V_TABLE (ChrisSelection)

#endif
