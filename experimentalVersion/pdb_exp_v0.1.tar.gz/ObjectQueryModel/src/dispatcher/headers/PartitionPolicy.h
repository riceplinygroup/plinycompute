//
// Created by Joseph Hwang on 9/12/16.
//

#ifndef OBJECTQUERYMODEL_PARTITIONPOLICY_H
#define OBJECTQUERYMODEL_PARTITIONPOLICY_H

#include "DataTypes.h"
#include "Handle.h"
#include "Object.h"
#include "Record.h"
#include "PDBVector.h"

#include "NodeDispatcherData.h"

#include <unordered_map>

namespace pdb {

class PartitionPolicy;
typedef std::shared_ptr<PartitionPolicy> PartitionPolicyPtr;

/**
 * An interface used by DispatcherServer to properly map PDB::Objects to
 * the Storage Node which they should be stored. Calls to partition may be non-deterministic (see RandomPolicy).
 */
class PartitionPolicy {
public:

    enum Policy {RANDOM, FAIR, DEFAULT};

    /**
     * Partitions a Vector of PDB data into a number of smaller Vectors all mapped to a respective Storage Node
     *
     * @param toPartition a vector of PDB::Objects to be stored
     * @return a mapping from node ids to the PDB::Objects that should be stored there
     */
    virtual std::shared_ptr<std::unordered_map<NodeID, Handle<Vector<Handle<Object>>>>>
        partition(Handle<Vector<Handle<Object>>> toPartition) = 0;

    /**
     * Updates PartitionPolicy with a collection of all the available storage nodes in the cluster
     *
     * @param storageNodes a vector of the live storage nodes
     */
    virtual void updateStorageNodes(Handle<Vector<Handle<NodeDispatcherData>>> storageNodes) = 0;

};

}

#endif //OBJECTQUERYMODEL_PARTITIONPOLICY_H
