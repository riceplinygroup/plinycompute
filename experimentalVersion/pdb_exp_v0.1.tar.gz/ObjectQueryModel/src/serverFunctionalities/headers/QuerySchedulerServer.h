#ifndef QUERY_SCHEDULER_SERVER_H
#define QUERY_SCHEDULER_SERVER_H


#include "ServerFunctionality.h"
#include "ResourceInfo.h"
#include "Handle.h"
#include "PDBVector.h"
#include "QueryBase.h"
#include "ResourceInfo.h"
#include "JobStage.h"
#include "SimpleSingleTableQueryProcessor.h"
#include "PDBLogger.h"
#include "QueryGraphIr.h"
#include <vector>

namespace pdb {

class QuerySchedulerServer : public ServerFunctionality {

public:

       //destructor
       ~QuerySchedulerServer ();

       QuerySchedulerServer(PDBLoggerPtr logger);

       //constructor, initialize from catalog
       QuerySchedulerServer (std :: string resourceManagerIp, int port, PDBLoggerPtr logger, bool usePipelineNetwork = false);

       //initialization
       void initialize(bool isRMRunAsServer);

       //to transform optimized client query into a physical plan
       //each pipeline can have more than one output
       void parseOptimizedQuery(pdb_detail::QueryGraphIrPtr queryGraph);

       //to print parsed physical execution plan
       void printCurrentPlan();

       //to schedule the current job plan
       bool schedule(std :: string ip, int port, PDBLoggerPtr logger, ObjectCreationMode mode);

       //to schedule a job stage
       bool schedule(Handle<JobStage> &stage, PDBCommunicatorPtr communicator, ObjectCreationMode mode);

       //to schedule the current job plan on all available resources
       void schedule();

       //from the serverFunctionality interface... register the resource manager handlers
       void registerHandlers (PDBServer &forMe) override;

       void cleanup () override;       


protected:

       //current resources
       Handle<Vector<Handle<ResourceInfo>>> resources;

       // resource manager IP address
       std :: string resourceManagerIp;

       // port number
       int port;


       // physical plan
       std :: vector<Handle<JobStage>> currentPlan;

       // logger
       PDBLoggerPtr logger;


       bool usePipelineNetwork;

};


}



#endif
