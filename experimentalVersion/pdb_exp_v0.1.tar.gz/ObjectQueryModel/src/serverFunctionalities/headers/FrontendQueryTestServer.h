
#ifndef FRONTEND_QUERY_TEST_SERVER_H
#define FRONTEND_QUERY_TEST_SERVER_H

#include "ServerFunctionality.h"
#include "QueryBase.h"
#include "PDBServer.h"

namespace pdb {

class FrontendQueryTestServer : public ServerFunctionality {

public:

	FrontendQueryTestServer () {}

	void registerHandlers (PDBServer &forMe) override;

	// destructor
	~FrontendQueryTestServer ();

private:
	void computeQuery (std :: string setOutputName, std :: string setPrefix, int &whichNode, Handle <QueryBase> &computeMe, 
		std :: vector <std :: string> &tempSetsCreated);

	// this actually computes a selection query
	void doSelection (std :: string setOutputName, Handle <QueryBase> &computeMe);

	int tempSetName;

};

}

#endif
