/* 
 * File:   CacheStats.h
 * Author: Jia
 *
 * Created on October 27, 2015, 10:19 PM
 */

#ifndef CACHESTATS_H
#define	CACHESTATS_H

//TODO

class CacheStats {
public:
    int numHits;
    int numMisses;
    int numEvicted;
    int numCached;


};
#endif	/* CACHESTATS_H */

