/* 
 * File:   PDBFlushProducerWork.h
 * Author: Jia
 *
 * Created on October 22, 2015, 9:03 PM
 */

#ifndef PDBFLUSHPRODUCERWORK_H
#define	PDBFLUSHPRODUCERWORK_H

#include "PDBWork.h"
#include "PangeaStorageServer.h"
#include <memory>
using namespace std;
class PDBFlushProducerWork;
typedef shared_ptr<PDBFlushProducerWork> PDBFlushProducerWorkPtr;

class PDBFlushProducerWork : public pdb :: PDBWork {
public:
    PDBFlushProducerWork(pdb :: PangeaStorageServer * server);
    ~PDBFlushProducerWork() {
    };
    void execute(PDBBuzzerPtr callerBuzzer) override;

private:
    pdb :: PangeaStorageServer* server;

};



#endif	/* PDBFLUSHPRODUCERWORK_H */

