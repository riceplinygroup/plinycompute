/*
 * File:   PDBPage.cc
 * Author: Jia
 *
 */

#ifndef PDB_Page_C
#define PDB_Page_C

#include "PDBPage.h"
#include <cstring>
#include <stdlib.h>
#include <iostream>


PDBPage::PDBPage(char * dataIn, NodeID dataNodeID, DatabaseID dataDbID,
        UserTypeID dataTypeID, SetID dataSetID, PageID dataPageID, size_t dataSize,
        size_t shmOffset, int internalOffset) {
    //cout << "Page Data Offset = " << shmOffset << "\n";
    rawBytes = dataIn;
    nodeID = dataNodeID;
    dbID = dataDbID;
    typeID = dataTypeID;
    setID = dataSetID;
    pageID = dataPageID;
    size = dataSize;
    offset = shmOffset;
    numObjects = 0;
    this->curAppendOffset = 0;
    this->refCount = 0;
    this->pinned = true;
    this->dirty = false;
    this->inFlush = false;
    this->partitionId = (FilePartitionID)(-1);
    this->pageSeqInPartition = (unsigned int)(-1);
    pthread_mutex_init(&(this->refCountMutex), nullptr);
    pthread_rwlock_init(&(this->flushLock), nullptr);
    this->internalOffset = internalOffset;
}

PDBPage::~PDBPage() {
    //cout<<"PDBPage: freeing page...";
    freePage();
    //cout<<"PDBPage: cleaning locks...";
    pthread_mutex_destroy(&(this->refCountMutex));
    pthread_rwlock_destroy(&(this->flushLock));
    //cout<<"PDBPage: locks cleaned.";
}

/**
 * Prepare page head.
 */

void PDBPage::preparePage() {
   char * cur = this->rawBytes;
   * ((NodeID *) cur) = nodeID;
   cur = cur + sizeof (NodeID);
   * ((DatabaseID *) cur) = dbID;
   cur = cur + sizeof (DatabaseID);
   * ((UserTypeID *) cur) = typeID;
   cur = cur + sizeof (UserTypeID);
   * ((SetID *) cur) = setID;
   cur = cur + sizeof (SetID);
   * ((PageID *) cur) = pageID;
   cur = cur + sizeof (PageID);
   this->curAppendOffset = sizeof(NodeID) + sizeof(DatabaseID) + sizeof(UserTypeID) + sizeof(SetID) + sizeof(PageID);
   return;     
}


void PDBPage::readLock() {
    pthread_rwlock_rdlock(&(this->flushLock));
}

void PDBPage::readUnlock() {
    pthread_rwlock_unlock(&(this->flushLock));
}

void PDBPage::writeLock() {
    pthread_rwlock_wrlock(&(this->flushLock));
}

void PDBPage::writeUnlock() {
    pthread_rwlock_unlock(&(this->flushLock));
}

void * PDBPage::getBytes() {

        return this->rawBytes + sizeof(NodeID) + sizeof(DatabaseID) + sizeof(UserTypeID) + sizeof(SetID) + sizeof(PageID);

}

size_t PDBPage::getSize() {

        return this->size - (sizeof(NodeID) + sizeof(DatabaseID) + sizeof(UserTypeID) + sizeof(SetID) + sizeof(PageID));

}

void  PDBPage::unpin() {
    this->decRefCount();
}

void PDBPage::freePage() {
    //this->writeLock();
    //cout<<"PDBPage: got lock for freeing page data...";
    if (rawBytes != nullptr) {
        //we always free page data by SharedMem class when page is flushed or evicted, and we do not free page data here
        //If it comes to here, there must be a problem. Shared memory should already be freed, there could be memory leaks
        rawBytes = nullptr;
    }
    //cout<<"PDBPage: page data freed...";
    //this->writeUnlock();
    nodeID = -1;
    dbID = -1;
    typeID = -1;
    setID = -1;
    pageID = -1;
    offset = 0;
    size = 0;
    numObjects = 0;
    internalOffset = 0;
    //cout<<"PDBPage: page data reset...";
}

#endif






