
#include <iostream>

#include "InterfaceFunctions.h"
#include "QueryItermediaryRepTestsRunner.h"
#include "QueriesTestsRunner.h"
#include "qunit.h"


using QUnit::UnitTest;

using pdb::makeObjectAllocatorBlock;

using pdb_tests::runQueriesTests;
using pdb_tests::runQueryIrTests;

int main()
{
    makeObjectAllocatorBlock (1024 * 10, true);

    UnitTest qunit(std::cerr, QUnit::normal);

    runQueriesTests(qunit);
    runQueryIrTests(qunit);

    return qunit.errors();
}

