#!/bin/bash
# by Jia

rm /var/tmp/*.so
