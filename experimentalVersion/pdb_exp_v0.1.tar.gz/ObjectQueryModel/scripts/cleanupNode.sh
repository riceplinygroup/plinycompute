rm -rf pdbRoot
rm -rf CatalogDir/*
rm -rf logs/*
pkill -9 test603
