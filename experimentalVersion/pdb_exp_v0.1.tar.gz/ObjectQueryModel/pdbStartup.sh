#!/bin/bash
echo "Start up pdbServer using screen command"; 

screen -d -m ./bin/pdbServer $@;
